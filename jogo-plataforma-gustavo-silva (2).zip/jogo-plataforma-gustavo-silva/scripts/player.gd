extends CharacterBody2D

var speed = 250
var jump_velo = -400
var dir 
var gravity = 980
var jumps = 1
@onready var anim = $AnimatedSprite2D
var is_alive = true

func _ready() -> void:
	
	
	pass

func _physics_process(delta: float) -> void:
	
	move(delta)
	if is_alive:
		animations()
	pass

func move(delta):
	if is_alive:
		dir = Input.get_axis("left" , "right")
	
	velocity.x = dir * speed 
	
	if not is_on_floor():
		velocity.y += gravity * delta
	
	if Input.is_action_just_pressed("jump")and jumps > 0 and is_alive:
		velocity.y = jump_velo
		jumps -= 1
	
	if is_on_floor():
		jumps =1
	move_and_slide()
	
	pass

func animations ():
	
	if velocity.x != 0 and is_on_floor():
		anim.play("run")
		
	elif velocity.x ==0 and is_on_floor():
		anim.play("idle")
	
	if not is_on_floor() and jumps >=1 :
		anim.play("jump")
	
	if dir > 0:
		anim.flip_h = false
	
	elif dir <0:
		anim.flip_h = true
		
	pass

func die():
	is_alive = false
	anim.play("hit")
	
	$Area2D.queue_free()
	$CollisionShape2D.queue_free()
	velocity.y = -300.00
	
	$Camera2D.zoom = Vector2(2.0 , 2.0)
	Engine.time_scale = 0.5
	
	await  get_tree().create_timer(1.0).timeout
	Engine.time_scale = 1 
	
	get_tree().reload_current_scene()
	
	pass
