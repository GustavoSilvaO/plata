extends StaticBody2D
var life = 2 


func _on_area_2d_area_entered(area: Area2D) -> void:
	
	if area.is_in_group("player"):
		$AnimatedSprite2D.play("hit")
		life -= 1
		if life <=0:
			$CPUParticles2D.restart()
			$AnimatedSprite2D.queue_free()
			$Area2D/CollisionShape2D.set_deferred("disable", true)
			$CollisionShape2D.set_deferred("disable", true)
			
			
			await get_tree().create_timer(1.0).timeout
			
			queue_free()
	pass # Replace with function body.
